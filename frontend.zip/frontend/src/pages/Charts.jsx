export default function Charts() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Charts</h1>
      <p>Here’s where visual reports and analytics will go.</p>
    </div>
  );
}
